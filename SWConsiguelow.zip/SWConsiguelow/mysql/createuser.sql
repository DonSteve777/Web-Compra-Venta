CREATE USER 'consiguelowdb'@'localhost' IDENTIFIED BY 'consiguelowdb';
GRANT ALL PRIVILEGES ON `consiguelowdb`.* TO 'consiguelowdb'@'localhost';